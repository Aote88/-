package cn.gok.dto;

/**
 * @date 2021/3/17 16:02
 * @description
 */
public class FileVO {
    private String flag;
    private String fileName;

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
